import React,{Component} from 'react';


class LoginComponent extends Component{
    constructor(){
        super()

        this.state={
            email:'',
            password:''
        }
    }

    handleChangeEmail = (event) => {
        this.setState({email:event.target.value})
    }
    handleChangePassword = (event) => {
        this.setState({password:event.target.value})
    }
   
    render(){
        return(
            <div className="container">
                <div className="panel panel-info">
                    <div className="panel-heading">
                        Login
                    </div>
                    <div className="panel-body">
                        <div className="form-group">
                            <label>Email</label>
                            <input type="email" name="email" value={this.state.email}
                            className="form-control" onChange={this.handleChangeEmail} required/>
                        </div>
                        <div className="form-group">
                            <label>Password</label>
                            <input type="password" name="password" value={this.state.password}
                            className="form-control" onChange={this.handleChangePassword} required/>
                        </div>
                        <button className="btn btn-success" >
                            Login
                        </button>
                    </div>
                </div>
            </div>
        )
    }
}

export default LoginComponent;