import React,{Component} from 'react';


class RegisterComponent extends Component{
    constructor(){
        super()

        this.state={
            name:'',
            email:'',
            password:''
        }
    }

    handleChangeName = (event) => {
        this.setState({name:event.target.value})
    }
    handleChangeEmail = (event) => {
        this.setState({email:event.target.value})
    }
    handleChangePassword = (event) => {
        this.setState({password:event.target.value})
    }
    
    render(){
        return(
            <div className="container">
                <div className="panel panel-info">
                    <div className="panel-heading">
                        Register
                    </div>
                    <div className="panel-body">
                        <div className="form-group">
                            <label>Name</label>
                            <input type="text" name="user_name"  value={this.state.name}
                            className="form-control" onChange={this.handleChangeName} required/>
                        </div>
                        <div className="form-group">
                            <label>Email</label>
                            <input type="email" name="email" required value={this.state.email}
                            className="form-control" onChange={this.handleChangeEmail} required/>
                        </div>
                        <div className="form-group">
                            <label>Password</label>
                            <input type="password" name="password" required value={this.state.password}
                            className="form-control" onChange={this.handleChangePassword} required/>
                        </div>
                        <button className="btn btn-success" >
                            Register
                        </button>
                    </div>
                </div>
            </div>
        )
    }
}

export default RegisterComponent;