import React,{Component} from 'react';
import axios from 'axios';
import './movie.css';




const url = "http://www.omdbapi.com/?i=tt3896198&apikey=9f626a64"

class Details extends Component{
    constructor(){
        super()

        this.state={
            details:'',
            
        }
    }

    render(){
        var {details} = this.state;
        return(
            <div className="container bg">
                   <h3><span className="clr"> Movie-Title: </span>{details.Title}</h3>
                   <h4><span className="clr">Year:</span>{details.Year}</h4>
                   <h4><span className="clr">Rated:</span>{details.Rated}</h4>
                   <h4><span className="clr"> Realesed:</span>{details.Released}</h4>
                   <h4><span className="clr">Runtime:</span>{details.Runtime}</h4>
                   <h4><span className="clr">Details:</span>{details.Genre}</h4>
                   <h4><span className="clr">Director:</span>{details.Director}</h4>
                   <h4><span className="clr">Writter:</span>{details.Writer}</h4>
                   <h4><span className="clr">Actors:</span>{details.Actors}</h4>
                   <h4><span className="clr">Language:</span>{details.Language}</h4>
                   <h4><span className="clr">Awards:</span>{details.Awards}</h4>
                   <h4 className="clr">poster</h4>
                   <h4><img src="https://m.media-amazon.com/images/M/MV5BNjM0NTc0NzItM2FlYS00YzEwLWE0YmUtNTA2ZWIzODc2OTgxXkEyXkFqcGdeQXVyNTgwNzIyNzg@._V1_SX300.jpg"></img></h4>
                   <h4><span className="clr">Metascore:</span>{details.Metascore}</h4>
                   <h4><span className="clr">Metascore:</span>{details.Metascore}</h4>

                   
                
            </div>
        )
    }

    componentDidMount(){
        axios.get(url)
        .then((response) => {this.setState({details:response.data})})
    }
}

export default Details