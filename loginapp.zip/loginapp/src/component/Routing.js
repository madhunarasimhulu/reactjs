import React from 'react';
import {BrowserRouter,Route} from 'react-router-dom';
import Header from './Header';

import RegisterComponent from './RegisterComponent';
import LoginComponent from './LoginComponent';

import Movilist from './Movilist'


const Routing = () => {
    return(
        <div>
            <BrowserRouter>
                <Header/>
                <Route exact path="/" component={RegisterComponent}/>
                <Route exact path="/login" component={LoginComponent}/>
                
                
                <Route exact path="/movilist" component={Movilist}/>
            </BrowserRouter>
        </div>
    )
}

export default Routing;